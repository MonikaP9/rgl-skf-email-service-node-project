// const config = {
//   user: 'tms',
//   password: 'tms@123#',
//  //server: '202.189.254.89', 
//   server: '100.64.219.103',
//   port: 2016,
//   database: 'TMS',

// }
// module.exports = config;

// const config = {
//     user: 'sa',
//     password: 'Bcsp!@VD#2',
//     // server: '202.189.254.89', 
//     server: '192.168.3.12',
//     port: '',
//     database: 'RGL_SKF',

// }
// module.exports = config;

const config = {
    user: 'sa',
    password: 'Bcsp!@VD#2',
    // server: '202.189.254.89', 
    server: '192.168.3.11',
    port: 50133,
    database: 'RGL_SKF_Merge',

}
module.exports = config;